package com.example.basicchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicchatApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicchatApplication.class, args);
	}

}
